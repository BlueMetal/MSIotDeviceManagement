#pragma once
/// <summary>
///		Convert a time_t to a string with a specific format
/// </summary>
void Utils_GetFormattedDateFromTime(char* buffer, size_t buffer_size, time_t integer);