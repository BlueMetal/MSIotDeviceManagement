#include <stdio.h>
#include <stdlib.h>
#include <stdarg.h>
#include <string.h>
#include <time.h>
#include "utils.h"
#include "structs.h"



feature FEATURES[] = { 
	{ .name = "BlinkRate1",.displayName = "\"Blink Rate1\"",.methods = "\"BlinkRate1\""},
    { .name = "BlinkRate2",.displayName = "\"Blink Rate2\"",.methods = "\"BlinkRate2\"" },
    { .name = "BlinkRate3",.displayName = "\"Blink Rate3\"",.methods = "\"BlinkRate3\"" }
};

