#pragma once
#include <bits/alltypes.h>

typedef struct feature {
	const char name[32];
	const char displayName[32];
	const char methods[256];
}feature;