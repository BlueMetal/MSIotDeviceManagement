//#pragma once
#include "structs.h"
extern feature FEATURES[];
//extern const int FEATURES_NBR;